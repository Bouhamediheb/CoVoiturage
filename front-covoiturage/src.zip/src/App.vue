<template>
  <div>
    <Header/>
    <div class="signup-container">
    <Signup/>
  </div>
    <SearchRide/>
    <Landing/>
    <Footer/>
  </div>
</template>

<script>
import Footer from './components/HomePage/Footer.vue'
import Landing from './components/HomePage/Landing.vue'
import Header from './components/HomePage/Header.vue'
import Signup from './components/HomePage/Signup.vue'
import SearchRide from './components/HomePage/SearchRide.vue'

export default {
  components: {
    Footer,
    Landing,
    Header,
    Signup,
    SearchRide
  }
}
</script>

<style scoped>
.signup-container {
  display: block;
  clear: both;
}
</style>
